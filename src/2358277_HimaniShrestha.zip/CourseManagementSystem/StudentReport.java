package CourseManagementSystem;
import java.awt.EventQueue;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import java.awt.Panel;
import java.awt.Color;
import java.awt.Font;
//jframe to display updated results
public class StudentReport extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentReport frame = new StudentReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudentReport() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 739, 519);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(23, 113, 704, 339);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"First Name", "Last Name", "Email", "Course", "Marks"
			}
		));
		
		JLabel lblStudentName = new JLabel("Student Name:");
		lblStudentName.setBounds(33, 86, 133, 15);
		contentPane.add(lblStudentName);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setBounds(482, 86, 133, 15);
		contentPane.add(lblEmail);
		
		JLabel studentName = new JLabel("Name");
		studentName.setBounds(179, 86, 114, 15);
		contentPane.add(studentName);
		
		JLabel studentEmail = new JLabel("mail");
		studentEmail.setBounds(627, 86, 86, 15);
		contentPane.add(studentEmail);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(23, 65, 704, 15);
		contentPane.add(separator);
		//		pannel.setBorder(BorderFactory.createRaisedBevelBorder());.
				
		
				JLabel lblResult = new JLabel("Student Report");
				lblResult.setBounds(23, 10, 180, 35);
				contentPane.add(lblResult);
				lblResult.setBackground(new Color(255, 255, 255));
				lblResult.setFont(new Font("Dialog", Font.BOLD, 16));
		
	}
}
